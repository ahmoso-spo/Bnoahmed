import logging
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes
from keep_alive import keep_alive

TOKEN = 'YOUR_BOT_TOKEN'

logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)

intro_message = """أهلاً بك في بوت الخطط التمريضية!
هنا تقدر تبحث عن أي مرض وتشوف أهم التشخيصات التمريضية المرتبطة بيه مع رقم الصفحة من مصدر NANDA بدقة وسرعة.
البوت مصمم ليساعد طلاب التمريض على تنظيم دراستهم بسهولة واحتراف.
تحياتي: أحمد سعد"""

case_mapping = {
    "stroke": [
        {"name": "IMPAIRED PHYSICAL MOBILITY", "printed": "208–209"},
        {"name": "SELF-CARE DEFICIT", "printed": "550–552"}
    ],
    "diabetes mellitus": [
        {"name": "RISK FOR UNSTABLE BLOOD GLUCOSE LEVEL", "printed": "478"},
        {"name": "DEFICIENT KNOWLEDGE", "printed": "172"}
    ]
    # باقي الأمراض تضاف هنا...
}

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(intro_message)

async def plan(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text("اكتب اسم المرض مثل: /plan stroke")
        return

    case = ' '.join(context.args).lower()
    if case not in case_mapping:
        await update.message.reply_text("ما عندي خطط لهذا المرض حالياً.")
        return

    results = []
    for plan in case_mapping[case]:
        result = f"التشخيص: {plan['name']}
الصفحة المطبوعة: {plan['printed']}
"
        results.append(result)

    await update.message.reply_text('\n'.join(results))

print("البوت شغّال... جرّب /plan stroke أو /plan diabetes mellitus")

keep_alive()

app = ApplicationBuilder().token(TOKEN).build()
app.add_handler(CommandHandler("start", start))
app.add_handler(CommandHandler("plan", plan))
app.run_polling()